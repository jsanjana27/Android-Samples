package com.example.customview

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.annotation.ColorInt
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import java.util.*

/**
Created by sanjana on 16/4/20
 */
class PieChartView(context: Context, attributeSet: AttributeSet) : View(context, attributeSet) {

    private val DEFAULT_MAX_SWEEP_ANGLE = 75
    private val DEFAULT_ARC_SPACE = 3 // Default spacious between arc is 3 degree

    private val rect = RectF()
    private var chartDataValues: ArrayList<ChartInfo>? =
        null

    
    private var mRedSweepAngle = 0
    private var maximumDataValue = 0
    private var defaultArcPaint: Paint? = null

    fun PieChartView(context: Context?) {
        PieChartView(context, null)
    }

    fun PieChartView(
        context: Context?,
        @Nullable attrs: AttributeSet?
    ) {
        PieChartView(context, attrs, 0)
    }

    fun PieChartView(
        context: Context?,
        @Nullable attrs: AttributeSet?,
        defStyleAttr: Int
    ) {
        PieChartView(context, attrs, defStyleAttr) : super(context, attrs, defStyleAttr)
    }


    fun getMaximumDataValue(): Int {
        return maximumDataValue
    }

    fun setMaximumDataValue(maximumDataValue: Int) {
        this.maximumDataValue = maximumDataValue
    }

    private fun dataBuilder(): DataBuilder? {
        return DataBuilder()
    }

    fun loadPieChartView() {
        setSweepAngle(0)
        requestLayout()
    }

    @NonNull
    private fun getDefaultPaint(style: Paint.Style): Paint? {
        val paint = Paint()
        paint.isAntiAlias = true
        paint.style = style
        return paint
    }

    private fun outerCirclePaint(@ColorInt color: Int): Paint? {
        val mWidth = width
        val mHeight = height
        val min = Math.min(mWidth, mHeight).toFloat()
        val fat = min / 7
        val paint = getDefaultPaint(Paint.Style.STROKE)
        paint!!.color = color
        paint.strokeCap = Paint.Cap.BUTT
        paint.strokeWidth = fat
        paint.isFilterBitmap = true
        return paint
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        var minimumSize: Int = Math.min(widthMeasureSpec, heightMeasureSpec)
        if (minimumSize <= 0) {
            val res = resources
            minimumSize = res.getDimensionPixelSize(R.dimen.default_chart_height_width)
        }
        val widthMode = MeasureSpec.getMode(widthMeasureSpec)
        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        val heightMode = MeasureSpec.getMode(heightMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)

        val width: Int
        val height: Int


        width = if (widthMode == MeasureSpec.EXACTLY) {
            widthSize
        } else if (widthMode == MeasureSpec.AT_MOST) {
            Math.min(minimumSize, widthSize)
        } else {
            minimumSize
        }

        height = if (heightMode == MeasureSpec.EXACTLY) {
            heightSize
        } else if (heightMode == MeasureSpec.AT_MOST) {
            Math.min(minimumSize, heightSize)
        } else {
            minimumSize
        }
        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        canvas!!.drawColor(Color.TRANSPARENT)


        val minSize = Math.min(width, height).toFloat()
        val fat = minSize / 7
        val half = minSize / 2

        drawSplitterArc(half, fat, canvas)
    }

    private fun drawSplitterArc(
        half: Float,
        fat: Float,
        @NonNull canvas: Canvas
    ) {
        if (null == defaultArcPaint) {
            val mWidth = width
            val mHeight = height
            val mRadius = half - fat + 10
            rect[mWidth / 2 - mRadius, mHeight / 2 - mRadius, mWidth / 2 + mRadius] =
                mHeight / 2 + mRadius
            defaultArcPaint = outerCirclePaint(Color.DKGRAY)

        }
        if (!chartDataValues!!.isEmpty()) {
            for (dataIndex in chartDataValues.indices) {
                val chartInfo = chartDataValues[dataIndex]
                defaultArcPaint!!.color = chartInfo.chartColor
                canvas.drawArc(
                    rect,
                    chartInfo.startAngle,
                    chartInfo.endAngle,
                    false,
                    defaultArcPaint!!
                )
            }
        }
    }

    fun getSweepAngle(): Int {
        return mRedSweepAngle
    }

    fun setSweepAngle(mRedSweepAngle: Int) {
        this.mRedSweepAngle = mRedSweepAngle
    }

    internal class ChartInfo {
        private var chartName: String? = null
        private var chartValue = 0
        private val startAngle = 0f
        private val currentAngle = 0f
        private val endAngle = 0f

        @ColorInt
        private var chartColor = 0

        companion object {
            fun createChartInfo(
                chartName: String?,
                data: Int,
                @ColorInt arcColor: Int
            ): ChartInfo {
                val chartInfo = ChartInfo()
                chartInfo.chartName = chartName
                chartInfo.chartValue = data
                chartInfo.chartColor = arcColor
                return chartInfo
            }
        }
    }

    class DataBuilder {

        private fun DataBuilder() {
            chartDataValues = ArrayList<ChartInfo>()
        }
    }
}